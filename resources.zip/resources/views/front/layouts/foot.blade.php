  <!-- Vendor JS Files -->
  <script src="assets/front/vendor/jquery/jquery.min.js"></script>
  <script src="assets/front/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/front/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/front/vendor/php-email-form/validate.js"></script>
  <script src="assets/front/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/front/vendor/venobox/venobox.min.js"></script>
  <script src="assets/front/vendor/owl.carousel/owl.carousel.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/front/js/main.js"></script>