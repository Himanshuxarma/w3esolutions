
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('product_select','active'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <a class="btn btn-sm btn-success  " href="<?php echo e(route('productsCreate')); ?>"> Create Product</a>

                <div class="card-tools">
                    <div class="input-group input-group-sm" style="width: 150px;">
                        <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th scope="col" width="10%">#</th>
                            <th scope="col" width="10%">Cat Id</th>
                            <th scope="col" width="10%">Title</th>
                            <th scope="col" width="10%">Slug</th>
                            <th scope="col" width="10%">Description</th>
                            <th scope="col" width="10%">Image</th>
                            <th scope="col" width="10%">Price</th>
                            <th scope="col" width="10%">Featured</th>
                            <th scope="col" width="10%">Status</th>
                            <th scope="col" width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->cat_id); ?></td>
                            <td><?php echo e($product->title); ?></td>
                            <td><?php echo e($product->slug); ?></td>
                            <td><?php echo e(strlen(strip_tags($product->description) < 100 ) ? substr(strip_tags($product->description), 0, 50).' ...' : strip_tags($product->description)); ?>

                            </td>
                            <td>
                                <img src="/uploads/products/<?php echo e($product->image); ?>" alt="<?php echo e($product->image); ?>"
                                    width="50%" />
                            </td>
                            <td>₹<?php echo e($product->price); ?></td>
                            <?php if($product->is_featured =="1"): ?>
                            <td> <a href="<?php echo e(route('featuredStatus',$product->id)); ?>" class="text-success">Featured</a>
                            </td>
                            <?php else: ?>
                            <td> <a href="<?php echo e(route('featuredStatus',$product->id)); ?>" class="text-danger">Unfeatured</a>
                            </td>
                            <?php endif; ?>
                            <?php if($product->status == "1"): ?>
                            <td>
                                <a href="<?php echo e(route('updateStatus',$product->id)); ?>" class="text-success">Active</a>
                            </td>
                            <?php else: ?>
                            <td>
                                <a href="<?php echo e(route('updateStatus',$product->id)); ?>" class="text-danger">Inactive</a>
                            </td>
                            <?php endif; ?>
                            <td>

                                <div class="input-group-prepend">
                                    <button type="button" class="btn btn-default dropdown-toggle"
                                        data-toggle="dropdown">
                                        Action
                                    </button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="<?php echo e(route('productEdit',$product->id)); ?>">Edit</a>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('productDelete',$product->id)); ?>">Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>

        </div>

    </div>
</div>


<script>
    setTimeout(function () {
        $('.hide1').fadeOut('slow');
    }, 1500);

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/product/index.blade.php ENDPATH**/ ?>