
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('contact_select','active'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
           

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" >
                <table class="table table-head-fixed text-nowrap">
                <thead>
                            <tr>
                                <th scope="col" width="10%">#</th>
                                <th scope="col" width="10%">Full Name</th>
                                <th scope="col" width="10%">Email</th>
                                <th scope="col" width="10%">Phone</th>
                                <th scope="col" width="10%">Subject</th>
								   <th scope="col" width="10%">Message</th>
                                <th scope="col" width="10%">Action</th>

                            </tr>
                        </thead>
                  <tbody>
                              <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($contact->id); ?></td>
                                <td><?php echo e($contact->full_name); ?></td>
                                <td><?php echo e($contact->email); ?></td>
                                <td><?php echo e($contact->phone); ?></td>
								<td><?php echo e($contact->subject); ?></td>
                                <td><?php echo e($contact->message); ?></td>
                              

                              <div class="input-group-prepend">
                              <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                              Action
                              </button>
                              <div class="dropdown-menu">
                                <a class="dropdown-item" href="javascript:voild(0);">Edit</a>
                              <a class="dropdown-item" href="javasceript:voild(0);">Delete</a>
                            </div>
                              </div>
                        </td>
                      </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
                
                </table>
              </div>
             
            </div>
           
          </div>
        </div>


<script>
setTimeout(function() {
    $('.hide1').fadeOut('slow');
}, 1500);
</script>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/enquiries/index.blade.php ENDPATH**/ ?>