
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('testimonial_select','active'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <?php if($message = Session::get('success')): ?>

                <p class="alert alert-success hide1 ">
                    <?php echo e($message); ?>

                </p>
                <?php endif; ?>

                <a class="btn btn-sm btn-success  " href="<?php echo e(route('testimonialsCreate')); ?>"> Create Testimonial</a>

                <div class="card-tools">
                    <div class="input-group input-group-sm" style="width: 150px;">
                        <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-body table-responsive p-0">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th scope="col" width="10%">#</th>
                            <th scope="col" width="10%">Title</th>
                            <th scope="col" width="10%">Description</th>
                            <th scope="col" width="10%"> Image</th>
                            <th scope="col" width="10%"> Rating</th>
                            <th scope="col" width="10%">Status</th>
                            <th scope="col" width="10%">Action</th>
                       </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->id); ?></td>
                            <td><?php echo e($data->title); ?></td>
                            <td><?php echo e(strlen(strip_tags($data->description) < 100 ) ? substr(strip_tags($data->description), 0, 100).' ...' : strip_tags($data->description)); ?></td>
                            <td><img src="/uploads/testimonials/<?php echo e($data->image); ?>" alt="<?php echo e($data->image); ?>" width="50%"/></td>
                            <td><?php echo e($data->rating); ?></td>
                                 <?php if($data->status == "1"): ?>

                            <td class="project-state">
                                <a href="<?php echo e(route('testimonialsStatus',$data->id)); ?>"><span class="badge badge-success">Active</span></a>
                            </td>
                            <?php else: ?>
                            <td class="project-state">
                                <a href="<?php echo e(route('testimonialsStatus',$data->id)); ?>"><span class="badge badge-danger">Inactive</span></a>
                            </td>
                            <?php endif; ?>
                            <td>
                                <div class="input-group-prepend">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"> Action</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="<?php echo e(route('testimonialsEdit',$data->id)); ?>">Edit</a>
                                        <a class="dropdown-item" href="<?php echo e(route('testimonialsDelete',$data->id)); ?>">Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>
<script>
    setTimeout(function () {
        $('.hide1').fadeOut('slow');
    }, 5000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/testimonial/index.blade.php ENDPATH**/ ?>