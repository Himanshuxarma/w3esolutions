
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            <div class="card-header">
                  <h3 class="card-title">Update Tech Stacks</h3>
             </div>

             <form  action="<?php echo e(route('techstacksUpdate',$techstacks->id)); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>

                 <div class="card-body">
                   <div class="row">
                      <div class="col-md-6">
                         <div class="form-group">
                            <label for="technology"> Technology </label>
                            <input type="text" name="technology" class="form-control" value="<?php echo e($techstacks->technology); ?>" require placeholder="Enter  technology">
                         </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="tech_icon">Tech Icon</label>
                            <input type="text" name="tech_icon" class="form-control"value="<?php echo e($techstacks->tech_icon); ?>" require placeholder="tech_icon">
                          </div>
                        </div>
                    </div>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="description">Description</label>
                          <textarea id="summernote" name="description"><?php echo e($techstacks->description); ?> </textarea>
                        </div>
                      </div>
                      
                   </div>

                        <div class="form-group">
                          <div class="form-check">
                          <input class="form-check-input" name="status" value="1"type="checkbox" <?php echo e(($techstacks->status==1 ? 'checked': '')); ?>>
                            <label class="form-check-label">Status</label>
                         </div>
                       </div>

                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                </form>
            </div>
          </div>
    
        </div>
     </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>

<script>
$(function () {
// Summernote
$('#summernote').summernote()

// CodeMirror
CodeMirror.fromTextArea(document.getElementById("codeMirrorDemo"), {
mode: "htmlmixed",
theme: "monokai"
});
})
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/techstacks/edit.blade.php ENDPATH**/ ?>