
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('users_select','active'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Users</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>UserName</th>
                                    <th>Email</th>
                                    <th>Email Verified At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td><?php echo e($data->email_verified_at); ?></td>
                                    <td>
                                        <div class="input-group-prepend">
                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown"> Action</button>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="javascript:voild(0);">Edit</a>
                                                <a class="dropdown-item" href="<?php echo e(route('userDelete',$data->id)); ?>">Delete</a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/users/index.blade.php ENDPATH**/ ?>