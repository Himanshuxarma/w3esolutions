<footer class="main-footer">
    <strong>Copyright &copy; 2023-2024 <a href="https://adminlte.io">W3solutions</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Ramesh Singh</b>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>