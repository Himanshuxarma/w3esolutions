
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('category_select','active'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
            <?php if($message = Session::get('success')): ?>
            <p class="alert alert-success hide1 ">
            <?php echo e($message); ?>

            </p>
            <?php endif; ?>
                <a class="btn btn-sm btn-success  " href="<?php echo e(route('categoryCreate')); ?>"> Create Category</a>

                <div class="card-tools">
                    <div class="input-group input-group-sm" style="width: 150px;">
                        <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                        <div class="input-group-append">
                            <button type="submit" class="btn btn-default">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0">
                <table class="table table-head-fixed text-nowrap">
                    <thead>
                        <tr>
                            <th scope="col" width="10%">#</th>
                            <th scope="col" width="10%">Name</th>
                            <th scope="col" width="10%">Slug</th>
                            <th scope="col" width="10%">Description</th>
                            <th scope="col" width="10%">Banner Image</th>
                            <th scope="col" width="10%">Status</th>
                            <th scope="col" width="10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cat->id); ?></td>
                            <td><?php echo e($cat->name); ?></td>
                            <td><?php echo e($cat->slug); ?></td>
                            <td><?php echo e(strlen(strip_tags($cat->description) < 100 ) ? substr(strip_tags($cat->description), 0, 50).' ...' : strip_tags($cat->description)); ?>

                            </td>
                            <td>
                                <img src="/uploads/categories/<?php echo e($cat->banner_image); ?>" alt="<?php echo e($cat->banner_image); ?>"width="50%" />
                            </td>

                            <?php if($cat->status == "1"): ?>
                            <td>
                                <a href="<?php echo e(route('categoryStatus',$cat->id)); ?>" class="text-success">Active</a>
                            </td>
                            <?php else: ?>
                            <td>
                                <a href="<?php echo e(route('categoryStatus',$cat->id)); ?>" class="text-danger">Inactive</a>
                            </td>
                            <?php endif; ?>
                            <td>

                                <div class="input-group-prepend">
                                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">Action</button>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="<?php echo e(route('categoryEdit',$cat->id)); ?>">Edit</a>
                                        <a class="dropdown-item" href="<?php echo e(route('categoryDelete',$cat->id)); ?>">Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>

        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>
<script>
setTimeout(function() {
$('.hide1').fadeOut('slow');
}, 5000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/category/index.blade.php ENDPATH**/ ?>