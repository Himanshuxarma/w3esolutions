
<?php $__env->startSection('customstyle'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Update Project</h3>
                    </div>

                    <form id="quickForm" action="<?php echo e(route('projectsUpdate',$projects->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>


                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="title"> Category Name </label>
                                        <select class="form-control" name="cat_id" id="cat_id">
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>{
                                            <option value="<?php echo e($cat->id); ?>"><?php if($cat->id==$projects->cat_id): ?><?php endif; ?><?php echo e($cat->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="title"> Title </label>
                                            <input type="text" name="title" class="form-control"value="<?php echo e($projects->title); ?>" id="product_title" require placeholder="Enter  Title">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="page_name">Slug</label>
                                            <input type="text" name="slug" class="form-control" value="<?php echo e($projects->slug); ?>" id="product_slug" require placeholder="slug">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="description">Description</label>
                                            <textarea id="summernote" name="description"><?php echo e($projects->description); ?> </textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="image"> Image</label>
                                            <input type="file" name="image" class="form-control" id="image" require placeholder=" Image">
                                            <img src="/uploads/projects/<?php echo e($projects->image); ?>" alt="<?php echo e($projects->image); ?>" width="30%" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input class="form-check-input" name="is_featured" value="1" type="checkbox"<?php echo e(($projects->is_featured==1 ? 'checked': '')); ?>>
                                    <label class="form-check-label">Is Featured ?</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input class="form-check-input" name="status" value="1" type="checkbox"<?php echo e(($projects->status==1 ? 'checked': '')); ?>>
                                    <label class="form-check-label">Status</label>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('customscript'); ?>
<script>
    $(function () {
        // Summernote
        $('#summernote').summernote()

        // CodeMirror
        CodeMirror.fromTextArea(document.getElementById("codeMirrorDemo"), {
            mode: "htmlmixed",
            theme: "monokai"
        });
    })

</script>

<script>
    var slug = function (str) {
        var $slug = '';
        var trimmed = $.trim(str);
        $slug = trimmed.replace(/[^a-z0-9-]/gi, '-').
        replace(/-+/g, '-').
        replace(/^-|-$/g, '');
        return $slug.toLowerCase();
    }

    $('#product_title').keyup(function () {
        var takedata = $(this).val()
        $('#product_slug').val(slug(takedata));
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/admin/project/edit.blade.php ENDPATH**/ ?>