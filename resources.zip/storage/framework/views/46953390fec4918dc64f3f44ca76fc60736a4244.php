<!DOCTYPE html>
<html lang="en">
<!-- head-->
<?php echo $__env->make('front.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

  <!-- ======= Header ======= -->
 <?php echo $__env->make('front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->
      
  <!-- ======= Hero Section ======= -->
 <?php echo $__env->make('front.layouts.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Hero -->

  <main id="main">
<?php echo $__env->yieldContent('content'); ?>
    
    <!-- ======= Contact Section ======= -->
  <?php echo $__env->make('front.layouts.enquiry', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Contact Section -->

  </main>
  <!-- End #main -->

  <!-- ======= Footer ======= -->
 <?php echo $__env->make('front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Vendor JS Files -->
<?php echo $__env->make('front.layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\w3solutions\resources\views/front/layouts/master.blade.php ENDPATH**/ ?>